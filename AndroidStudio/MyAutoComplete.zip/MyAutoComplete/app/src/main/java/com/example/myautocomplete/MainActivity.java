package com.example.myautocomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AutoCompleteTextView autoCompleteTextView= findViewById((R.id.autoCompleteTextView));
        ArrayAdapter<String>arrayAdapter = new ArrayAdapter<>(MainActivity.this,
                R.layout.layout_item_autocomplete, R.id.tvCustom, getResources().getStringArray(R.array.sweets));

        autoCompleteTextView.setAdapter(arrayAdapter);
    }
}